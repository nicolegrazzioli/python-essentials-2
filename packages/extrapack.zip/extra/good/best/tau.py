#! /usr/bin/env python3
 
""" module: tau """
 
def funT():
  return "Tau"
 
if __name__ == "__main__":
  print("I prefer to be a module.")