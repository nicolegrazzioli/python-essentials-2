#! /usr/bin/env python3
 
""" module: omega """
 
def funO():
  return "Omega"
 
if __name__ == "__main__":
  print("I prefer to be a module.")